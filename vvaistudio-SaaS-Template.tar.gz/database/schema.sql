CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    google_id VARCHAR(64) UNIQUE,
    email VARCHAR(120),
    name VARCHAR(120),
    plan ENUM('FREE','PREMIUM') DEFAULT 'FREE',
    lifetime_ops INT DEFAULT 0,
    stripe_customer_id VARCHAR(120) NULL,
    stripe_subscription_id VARCHAR(120) NULL,
    cancel_at_period_end TINYINT(1) DEFAULT 0,
    cancel_at DATETIME NULL,
    current_period_end DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS operations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    file_size INT,
    status ENUM('SUCCESS','FAILED') NOT NULL,
    operation_type ENUM('bg_removal', 'transform') DEFAULT 'bg_removal',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_operations_user_date ON operations (user_id, date);
CREATE INDEX idx_operations_user_status ON operations (user_id, status);
CREATE UNIQUE INDEX idx_users_stripe_customer_id ON users (stripe_customer_id);

