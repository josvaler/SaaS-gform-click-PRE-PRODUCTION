<?php
declare(strict_types=1);

use App\Models\UserRepository;
use Stripe\Webhook;

require __DIR__ . '/../../config/bootstrap.php';

$payload = file_get_contents('php://input');
$signature = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

if (!class_exists(Webhook::class)) {
    http_response_code(200);
    echo json_encode(['status' => 'ok']);
    exit;
}

try {
    $event = Webhook::constructEvent(
        $payload,
        $signature,
        $stripeConfig['webhook_secret']
    );
} catch (Throwable $exception) {
    http_response_code(400);
    echo json_encode(['error' => $exception->getMessage()]);
    exit;
}

$type = $event->type;
$data = $event->data->object;
$googleId = $data->metadata->google_id ?? null;
$stripeCustomerId = $data->customer ?? null;

if ($googleId) {
    try {
        $pdo = db();
        $userRepo = new UserRepository($pdo);
        $user = $userRepo->findByGoogleId($googleId);

        if ($user) {
            if ($type === 'checkout.session.completed') {
                $userRepo->updatePlan((int)$user['id'], 'PREMIUM');
                if ($stripeCustomerId) {
                    $userRepo->updateStripeCustomerId((int)$user['id'], $stripeCustomerId);
                    if (isset($_SESSION['user']['google_id']) && $_SESSION['user']['google_id'] === $googleId) {
                        $_SESSION['user']['stripe_customer_id'] = $stripeCustomerId;
                        $_SESSION['user']['plan'] = 'PREMIUM';
                    }
                }
            }

            if ($type === 'customer.subscription.deleted') {
                $userRepo->updatePlan((int)$user['id'], 'FREE');
                if (isset($_SESSION['user']['google_id']) && $_SESSION['user']['google_id'] === $googleId) {
                    $_SESSION['user']['plan'] = 'FREE';
                }
            }

            if ($type === 'customer.subscription.updated') {
                $subscriptionId = $data->id ?? null;
                $cancelAtPeriodEnd = $data->cancel_at_period_end ?? false;
                $cancelAt = isset($data->cancel_at) && $data->cancel_at 
                    ? gmdate('Y-m-d H:i:s', (int)$data->cancel_at) 
                    : null;
                $currentPeriodEnd = isset($data->current_period_end) && $data->current_period_end
                    ? gmdate('Y-m-d H:i:s', (int)$data->current_period_end)
                    : null;

                $updates = [];
                if ($subscriptionId) $updates['stripe_subscription_id'] = $subscriptionId;
                if ($cancelAtPeriodEnd !== null) $updates['cancel_at_period_end'] = $cancelAtPeriodEnd ? 1 : 0;
                if ($cancelAt) $updates['cancel_at'] = $cancelAt;
                if ($currentPeriodEnd) $updates['current_period_end'] = $currentPeriodEnd;

                if (!empty($updates)) {
                    $userRepo->updateSubscriptionMetadata((int)$user['id'], $updates);
                }
            }
        }
    } catch (Throwable $exception) {
        error_log('Webhook processing error: ' . $exception->getMessage());
    }
}

http_response_code(200);
echo json_encode(['status' => 'ok']);

