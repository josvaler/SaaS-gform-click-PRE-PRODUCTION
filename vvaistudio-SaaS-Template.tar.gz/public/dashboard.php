<?php
declare(strict_types=1);

require __DIR__ . '/../config/bootstrap.php';
require_auth();

$user = session_user();
$pageTitle = 'Dashboard';
$navLinksLeft = [
    ['label' => 'Dashboard', 'href' => '/dashboard'],
    ['label' => 'Price', 'href' => '/price'],
    ['label' => 'My Plan', 'href' => '/billing'],
];
$navLinksRight = [
    ['label' => 'Logout', 'href' => '/logout'],
];

$currentPlan = ($user['plan'] ?? 'FREE');
$isPremium = ($currentPlan === 'PREMIUM');

require __DIR__ . '/../views/partials/header.php';
?>

<section style="padding: 4rem 0;">
    <div class="container" style="max-width: 800px;">
        <div class="card">
            <div class="card-header">
                <div>
                    <h2>Welcome, <?= html($user['name'] ?? 'User') ?>!</h2>
                    <p class="text-muted">Your Dashboard</p>
                </div>
                <span class="badge <?= $isPremium ? 'premium-badge' : 'free-badge' ?>">
                    <?= $isPremium ? '💎 PREMIUM' : '⭐ FREE' ?>
                </span>
            </div>

            <div style="padding: 1.5rem;">
                <div style="margin-bottom: 1.5rem;">
                    <h3>Account Information</h3>
                    <p><strong>Email:</strong> <?= html($user['email'] ?? 'N/A') ?></p>
                    <p><strong>Plan:</strong> <?= html($currentPlan) ?></p>
                    <p><strong>Lifetime Operations:</strong> <?= number_format($user['lifetime_ops'] ?? 0) ?></p>
                </div>

                <?php if (!$isPremium): ?>
                    <div class="alert alert-info">
                        <strong>Upgrade to Premium</strong><br>
                        Get access to premium features and unlimited operations.
                        <a href="/billing" class="btn btn-primary" style="margin-top: 1rem;">Upgrade Now</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/../views/partials/footer.php'; ?>

