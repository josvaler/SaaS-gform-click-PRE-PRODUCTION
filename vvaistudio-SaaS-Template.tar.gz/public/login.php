<?php
declare(strict_types=1);

use App\Models\UserRepository;

require __DIR__ . '/../config/bootstrap.php';

if (session_user()) {
    redirect('/dashboard');
}

$pageTitle = 'Login with Google';
$navLinksLeft = [
    ['label' => 'Back to Landing', 'href' => '/'],
    ['label' => 'Price', 'href' => '/price'],
];

$authError = null;
$authUrl = null;
$googleSdkAvailable = class_exists('\Google\Client');

if ($googleSdkAvailable) {
    $client = new Google\Client();
    $client->setClientId($googleConfig['client_id']);
    $client->setClientSecret($googleConfig['client_secret']);
    $client->setRedirectUri($googleConfig['redirect_uri']);
    $client->setAccessType('offline');
    $client->setPrompt($googleConfig['prompt']);
    $client->setScopes($googleConfig['scopes']);

    if (isset($_GET['action']) && $_GET['action'] === 'start') {
        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state'] = $state;
        $client->setState($state);
        redirect($client->createAuthUrl());
    }

    if (isset($_GET['code'])) {
        $state = $_GET['state'] ?? '';
        if (empty($_SESSION['oauth_state']) || $state !== $_SESSION['oauth_state']) {
            $authError = 'Invalid OAuth state. Please try again.';
        } else {
            try {
                $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
                if (isset($token['error'])) {
                    $authError = 'Authentication failed: ' . $token['error'];
                } else {
                    $oauthService = new Google\Service\Oauth2($client);
                    $googleProfile = $oauthService->userinfo->get();

                    try {
                        $pdo = db();
                        $userRepo = new UserRepository($pdo);

                        $userRecord = $userRepo->upsertFromGoogle([
                            'google_id' => $googleProfile->id,
                            'email' => $googleProfile->email,
                            'name' => $googleProfile->name,
                        ]);

                        $_SESSION['user'] = [
                            'id' => (int)$userRecord['id'],
                            'google_id' => trim((string)$userRecord['google_id']),
                            'email' => strtolower(trim((string)$userRecord['email'])),
                            'name' => $userRecord['name'],
                            'plan' => $userRecord['plan'] ?? 'FREE',
                            'lifetime_ops' => (int)$userRecord['lifetime_ops'],
                            'avatar' => $googleProfile->picture,
                            'stripe_customer_id' => $userRecord['stripe_customer_id'] ?? null,
                        ];

                        unset($_SESSION['oauth_state']);
                        session_write_close();
                        
                        redirect('/dashboard');
                    } catch (Throwable $exception) {
                        $authError = 'Unable to persist user: ' . $exception->getMessage();
                        error_log('Login error: ' . $exception->getMessage());
                    }
                }
            } catch (Throwable $exception) {
                $authError = 'Unable to authenticate: ' . $exception->getMessage();
                error_log('OAuth error: ' . $exception->getMessage());
            }
        }
    }

    $authUrl = $client->createAuthUrl();
}

require __DIR__ . '/../views/partials/header.php';
?>

<section style="padding: 4rem 0;">
    <div class="container" style="max-width: 520px;">
        <div class="card">
            <div class="card-header">
                <div>
                    <h2>Login with Google</h2>
                    <p class="text-muted">Secure OAuth 2.0 sign-in</p>
                </div>
            </div>

            <?php if ($authError): ?>
                <div class="alert alert-error"><?= html($authError) ?></div>
            <?php endif; ?>

            <?php if ($googleSdkAvailable && $authUrl): ?>
                <div style="padding: 1.5rem;">
                    <a href="<?= html($authUrl) ?>" class="btn btn-primary" style="width: 100%;">
                        Sign in with Google
                    </a>
                </div>
            <?php else: ?>
                <div class="alert alert-error">
                    Google OAuth is not configured. Please check your environment variables.
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php require __DIR__ . '/../views/partials/footer.php'; ?>

