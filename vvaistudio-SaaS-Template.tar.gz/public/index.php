<?php
declare(strict_types=1);

require __DIR__ . '/../config/bootstrap.php';

$user = session_user();
$isLoggedIn = $user !== null && !empty($user);

// Auto-redirect logged-in users to dashboard
if ($isLoggedIn) {
    redirect('/dashboard');
}

$pageTitle = 'Welcome';
$navLinksLeft = [
    ['label' => 'Dashboard', 'href' => '/dashboard'],
    ['label' => 'Price', 'href' => '/price'],
];
$navLinksRight = $isLoggedIn
    ? [
        ['label' => 'Dashboard', 'href' => '/dashboard'],
        ['label' => 'My Plan', 'href' => '/billing'],
        ['label' => 'Logout', 'href' => '/logout'],
    ]
    : [
        ['label' => 'Price', 'href' => '/price'],
        ['label' => 'Login', 'href' => '/login'],
    ];

require __DIR__ . '/../views/partials/header.php';
?>

<section class="hero" style="padding: 4rem 0; background: linear-gradient(to bottom right, #0f172a, #1e293b);">
    <div class="container" style="max-width: 800px; text-align: center;">
        <h1 style="font-size: 3rem; font-weight: 700; margin-bottom: 1rem; color: white;">
            Welcome to <?= html($appConfig['name']) ?>
        </h1>
        <p style="font-size: 1.25rem; color: rgba(255, 255, 255, 0.8); margin-bottom: 2rem;">
            Get started with Google Login and Stripe subscriptions
        </p>
        <?php if (!$isLoggedIn): ?>
            <a href="/login" class="btn btn-primary" style="font-size: 1.1rem; padding: 0.75rem 2rem;">
                Get Started
            </a>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/../views/partials/footer.php'; ?>

