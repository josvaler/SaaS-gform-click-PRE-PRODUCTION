    </main>
    <footer>
        <div class="container">
            <div class="nav-links" style="justify-content: center; margin-bottom: 1rem;">
                <a href="/terms">Terms & Conditions</a>
                <a href="/privacy">Privacy Policy</a>
            </div>
            <p style="margin-bottom: 0.5rem;">
                © <?= date('Y') ?> <strong><?= html($appConfig['name']) ?></strong>
            </p>
            <p style="font-size: 0.85rem; color: var(--color-text-muted);">
                Built with ❤️
            </p>
        </div>
    </footer>
</body>
</html>

