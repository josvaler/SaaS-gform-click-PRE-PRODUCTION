<?php
if (!isset($pageTitle)) {
    $pageTitle = 'YourAppName';
}

$currentPath = $_SERVER['REQUEST_URI'] ?? '/';

$navLinksLeft = $navLinksLeft ?? [
    ['label' => 'Dashboard', 'href' => '/dashboard'],
    ['label' => 'Price', 'href' => '/price'],
];

$navLinksRight = $navLinksRight ?? [
    ['label' => 'My Plan', 'href' => '/billing'],
    ['label' => 'Logout', 'href' => '/logout'],
];

$isActive = function($href) use ($currentPath) {
    return strpos($currentPath, $href) !== false;
};

$currentUser = $_SESSION['user'] ?? null;
$userAvatar = $currentUser['avatar'] ?? null;
$userName = $currentUser['name'] ?? 'User';
$userPlan = $currentUser['plan'] ?? 'FREE';
$isPremium = $userPlan === 'PREMIUM';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= html($pageTitle) ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <header class="navbar" role="banner">
        <div class="logo">
            <a href="/" class="badge" aria-label="Home">
                <span>✨</span>
                <span><?= html($appConfig['name']) ?></span>
            </a>
        </div>
        <nav class="nav-links" aria-label="Main navigation">
            <?php foreach ($navLinksLeft as $link): ?>
                <a href="<?= html($link['href']) ?>" <?= $isActive($link['href']) ? 'class="active" aria-current="page"' : '' ?>>
                    <?= html($link['label']) ?>
                </a>
            <?php endforeach; ?>
        </nav>
        <nav class="nav-links" aria-label="User navigation">
            <?php foreach ($navLinksRight as $link): ?>
                <a href="<?= html($link['href']) ?>" <?= $isActive($link['href']) ? 'class="active" aria-current="page"' : '' ?>>
                    <?= html($link['label']) ?>
                </a>
            <?php endforeach; ?>
            
            <?php if ($userAvatar): ?>
                <div class="user-profile <?= $isPremium ? 'premium' : 'free' ?>">
                    <div class="user-avatar-wrapper">
                        <img src="<?= html($userAvatar) ?>" alt="<?= html($userName) ?>" class="user-avatar">
                    </div>
                    <div class="user-info">
                        <span class="user-name"><?= html($userName) ?></span>
                        <span class="plan-badge <?= $isPremium ? 'premium-badge' : 'free-badge' ?>">
                            <?= $isPremium ? '💎 PREMIUM' : '⭐ FREE' ?>
                        </span>
                    </div>
                </div>
            <?php endif; ?>
        </nav>
    </header>
    <main>

