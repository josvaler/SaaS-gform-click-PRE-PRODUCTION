<?php
/**
 * Billing Page Template
 * 
 * Expected variables:
 * @var array $user - User session data
 * @var string $currentPlan - Current plan (FREE/PREMIUM)
 * @var bool $isPremium - Whether user has premium plan
 * @var string|null $status - Status message (success/cancelled/error/etc)
 * @var bool $hasScheduledCancellation - Whether cancellation is scheduled
 * @var string|null $cancelDateFormatted - Formatted cancellation date
 */
?>
<section style="padding: 4rem 0;">
    <div class="container" style="max-width: 640px;">
        <!-- Current Plan Display -->
        <div class="card" style="margin-bottom: 2rem; <?php echo $isPremium ? 'border: 2px solid rgba(34, 211, 238, 0.5);' : 'border: 2px solid rgba(148, 163, 184, 0.3);'; ?>">
            <div style="text-align: center; padding: 1.5rem 0;">
                <div style="font-size: 0.9rem; color: var(--color-text-muted); margin-bottom: 0.5rem; text-transform: uppercase; letter-spacing: 1px;">Current Plan</div>
                <div style="font-size: 3.5rem; font-weight: 700; margin-bottom: 0.5rem; background: <?php echo $isPremium ? 'linear-gradient(135deg, #6366f1, #22d3ee);' : 'linear-gradient(135deg, #94a3b8, #64748b);'; ?> -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
                    <?php echo $isPremium ? 'PREMIUM' : 'FREE'; ?>
                </div>
                <div style="font-size: 1.1rem; color: var(--color-text-muted);">
                    <?php echo $isPremium ? '🎉 Unlimited Access' : 'Limited Access'; ?>
                </div>
                <?php if ($hasScheduledCancellation): ?>
                    <div class="alert alert-warning" style="margin-top: 1rem; margin-left: 1rem; margin-right: 1rem;">
                        <strong>Subscription Cancellation Scheduled</strong><br>
                        Your subscription will cancel on <?= html($cancelDateFormatted) ?>. You'll continue to have access until then.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <div>
                    <h2>Premium Plan</h2>
                    <p class="text-muted">Premium features and unlimited access</p>
                </div>
                <span class="badge">Stripe Secure</span>
            </div>

            <?php if ($status === 'success'): ?>
                <div class="alert alert-success">Subscription confirmed. Enjoy unlimited access!</div>
            <?php elseif ($status === 'cancelled'): ?>
                <div class="alert alert-error">Checkout cancelled. You were not charged.</div>
            <?php elseif ($status === 'error'): ?>
                <div class="alert alert-error">We could not reach Stripe. Please try again in a moment.</div>
            <?php elseif ($status === 'portal_error'): ?>
                <div class="alert alert-error">Unable to access billing portal. Please contact support.</div>
            <?php elseif ($status === 'portal_missing_customer'): ?>
                <div class="alert alert-error">We could not locate your subscription in Stripe. Please complete checkout first or contact support to sync your account.</div>
            <?php elseif ($status === 'customer_missing'): ?>
                <div class="alert alert-error">We couldn't find your existing Stripe subscription. Please contact support before trying to upgrade again.</div>
            <?php endif; ?>

            <p style="margin-bottom: 1.5rem;" class="text-muted">
                Premium unlocks unlimited access to all features, priority processing, and concierge support.
            </p>

            <?php if (!$isPremium): ?>
                <form action="/stripe/checkout" method="POST" style="margin-bottom: 1rem;">
                    <button class="btn btn-primary" type="submit" style="width: 100%;">Upgrade with Stripe Checkout</button>
                </form>
            <?php else: ?>
                <div class="alert alert-success">You are currently on the Premium plan.</div>
            <?php endif; ?>

            <?php if ($isPremium): ?>
                <form action="/stripe/portal" method="POST">
                    <button class="btn btn-outline" type="submit" style="width: 100%;">Manage Subscription</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</section>

