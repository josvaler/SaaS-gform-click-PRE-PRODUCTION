<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class UserRepository
{
    public function __construct(private PDO $db)
    {
    }

    public function findByGoogleId(string $googleId): ?array
    {
        $statement = $this->db->prepare('SELECT * FROM users WHERE TRIM(google_id) = TRIM(:google_id) LIMIT 1');
        $statement->execute(['google_id' => $googleId]);
        $user = $statement->fetch(PDO::FETCH_ASSOC);
        return $user ?: null;
    }

    public function findByEmail(string $email): ?array
    {
        $statement = $this->db->prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1');
        $statement->execute(['email' => $email]);
        $user = $statement->fetch(PDO::FETCH_ASSOC);
        return $user ?: null;
    }

    public function upsertFromGoogle(array $profile): array
    {
        $statement = $this->db->prepare(
            'INSERT INTO users (google_id, email, name, plan, lifetime_ops)
             VALUES (:google_id, :email, :name, COALESCE(:plan, "FREE"), COALESCE(:lifetime_ops, 0))
             ON DUPLICATE KEY UPDATE 
                email = VALUES(email), 
                name = VALUES(name), 
                updated_at = CURRENT_TIMESTAMP'
        );

        $statement->execute([
            'google_id' => trim((string)$profile['google_id']),
            'email' => isset($profile['email']) ? strtolower(trim((string)$profile['email'])) : null,
            'name' => $profile['name'] ?? null,
            'plan' => $profile['plan'] ?? 'FREE',
            'lifetime_ops' => $profile['lifetime_ops'] ?? 0,
        ]);

        return $this->findByGoogleId($profile['google_id']);
    }

    public function updatePlan(int $userId, string $plan): void
    {
        $statement = $this->db->prepare('UPDATE users SET plan = :plan WHERE id = :id');
        $statement->execute([
            'plan' => $plan,
            'id' => $userId,
        ]);
    }

    public function incrementLifetimeOps(int $userId): void
    {
        $statement = $this->db->prepare('UPDATE users SET lifetime_ops = lifetime_ops + 1 WHERE id = :id');
        $statement->execute(['id' => $userId]);
    }

    public function updateStripeCustomerId(int $userId, string $customerId): void
    {
        $statement = $this->db->prepare('UPDATE users SET stripe_customer_id = :customer_id WHERE id = :id');
        $statement->execute([
            'customer_id' => $customerId,
            'id' => $userId,
        ]);
    }

    public function updateSubscriptionMetadata(int $userId, array $attributes): void
    {
        $allowed = [
            'stripe_subscription_id',
            'cancel_at_period_end',
            'cancel_at',
            'current_period_end',
        ];

        $setParts = [];
        $params = ['id' => $userId];

        foreach ($allowed as $column) {
            if (array_key_exists($column, $attributes)) {
                $setParts[] = "{$column} = :{$column}";
                $params[$column] = $attributes[$column];
            }
        }

        if (empty($setParts)) {
            return;
        }

        $sql = 'UPDATE users SET ' . implode(', ', $setParts) . ' WHERE id = :id';
        $statement = $this->db->prepare($sql);
        $statement->execute($params);
    }
}

