<?php
declare(strict_types=1);

return [
    'client_id' => env('GOOGLE_CLIENT_ID', ''),
    'client_secret' => env('GOOGLE_CLIENT_SECRET', ''),
    'redirect_uri' => env('GOOGLE_REDIRECT_URI', 'http://localhost/login'),
    'prompt' => 'select_account',
    'scopes' => [
        'email',
        'profile',
    ],
];

