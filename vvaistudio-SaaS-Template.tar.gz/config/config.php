<?php
declare(strict_types=1);

return [
    'name' => 'YourAppName',
    'base_url' => env('APP_URL', 'http://localhost'),
    'uploads_dir' => __DIR__ . '/../../uploads',
    'processed_dir' => __DIR__ . '/../../processed',
];

