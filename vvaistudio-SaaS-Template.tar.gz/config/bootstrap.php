<?php
declare(strict_types=1);

// Prevent browser caching for dynamic PHP pages
if (!headers_sent()) {
    header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/database.php';

$autoloadPath = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    $baseDir = __DIR__ . '/../';

    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }

    $relativeClass = substr($class, strlen($prefix));
    $relativePath = str_replace('\\', '/', $relativeClass);
    
    // Try exact path first
    $file = $baseDir . $relativePath . '.php';
    
    if (file_exists($file)) {
        require_once $file;
        return;
    }
    
    // If not found, try with lowercase directory names (for case-sensitive filesystems)
    $parts = explode('/', $relativePath);
    if (count($parts) > 0) {
        // Convert first directory to lowercase (e.g., Models -> models)
        $parts[0] = strtolower($parts[0]);
        $file = $baseDir . implode('/', $parts) . '.php';
        
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

$googleConfig = require __DIR__ . '/google.php';
$appConfig = require __DIR__ . '/config.php';
$stripeConfig = require __DIR__ . '/stripe.php';

